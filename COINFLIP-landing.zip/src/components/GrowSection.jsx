import React from 'react';

const GrowSection = () => {
  return (
    <section id="grow" className="section">
      <div className="section-content">
        <h2>Grow your crypto portfolio</h2>
        <p>Earn yield, stake assets, and access exclusive investment opportunities as your holdings grow.</p>
        <button className="btn btn--ghost">Learn More</button>
      </div>
    </section>
  );
};

export default GrowSection;