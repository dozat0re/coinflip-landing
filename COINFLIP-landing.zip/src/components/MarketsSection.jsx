import React from 'react';

const MarketsSection = () => {
  return (
    <section id="markets" className="section">
      <div className="section-content">
        <h2>Real-time crypto markets</h2>
        <p>Track prices, volume, and trends across hundreds of cryptocurrencies with our advanced market tools.</p>
        <button className="btn btn--ghost">View Markets</button>
      </div>
    </section>
  );
};

export default MarketsSection;