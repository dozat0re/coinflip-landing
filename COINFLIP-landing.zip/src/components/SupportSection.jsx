import React from 'react';

const SupportSection = () => {
  return (
    <section id="support" className="section">
      <div className="section-content">
        <h2>24/7 human support</h2>
        <p>Real people, real answers — no bots. Our support team is available around the clock to help you.</p>
        <button className="btn btn--ghost">Contact Us</button>
      </div>
    </section>
  );
};

export default SupportSection;