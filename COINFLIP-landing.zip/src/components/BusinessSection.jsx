import React from 'react';

const BusinessSection = () => {
  return (
    <section id="business" className="section">
      <div className="section-content">
        <h2>Power your business with crypto</h2>
        <p>Accept Bitcoin and other cryptocurrencies as payment, integrate our APIs, and manage treasury with ease.</p>
        <button className="btn btn--ghost">For Business</button>
      </div>
    </section>
  );
};

export default BusinessSection;