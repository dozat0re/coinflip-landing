// src/components/FeaturesSection.jsx
import React from 'react';
import './FeaturesSection.css';

const FeaturesSection = () => {
  const features = [
    {
      title: 'Trade Desk',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M17 16L19 18M19 18L21 16M19 18V12M7 8L5 6M5 6L3 8M5 6V12M12 17C10.8954 17 10 16.1046 10 15C10 13.8954 10.8954 13 12 13C13.1046 13 14 13.8954 14 15C14 16.1046 13.1046 17 12 17Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 7C10.8954 7 10 6.10457 10 5C10 3.89543 10.8954 3 12 3C13.1046 3 14 3.89543 14 5C14 6.10457 13.1046 7 12 7Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
      description: 'Invest in crypto anytime, anywhere with our safe, secure, and easy to use online platform.',
      cta: 'Get Started →'
    },
    {
      title: 'CoinFlip ATMs',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="6" width="18" height="12" rx="2" stroke="currentColor" strokeWidth="2"/>
          <path d="M8 10H16M8 14H16" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          <circle cx="12" cy="12" r="2" stroke="currentColor" strokeWidth="2"/>
        </svg>
      ),
      description: 'We have thousands of ATMs located across the U.S. where you can easily convert cash to crypto.',
      cta: 'Find an ATM →'
    },
    {
      title: 'CoinFlip Wallet',
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 12H21M3 12C3 10.8954 3.89543 10 5 10H19C20.1046 10 21 10.8954 21 12M3 12C3 13.1046 3.89543 14 5 14H19C20.1046 14 21 13.1046 21 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 12V8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M12 16V14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ),
      description: 'Store your growing investments in our non-custodial wallet that gives you access to a full suite of DeFi services in one place.',
      cta: 'Download the App →'
    }
  ];

  return (
    <section className="features-section">
      <div className="features-grid">
        {features.map((feature, index) => (
          <div key={index} className="feature-card">
            <div className="feature-icon">
              {feature.icon}
            </div>
            <h3>{feature.title}</h3>
            <p>{feature.description}</p>
            <button className="btn btn--ghost feature-cta">
              {feature.cta}
            </button>
          </div>
        ))}
      </div>

      <div className="features-footer">
        <h2>A crypto investment platform that invests in you</h2>
        <p>We invest more resources than any other platform in making sure great support from real people is a click away, whenever you need it.</p>
        <button className="btn btn--primary">Get Started</button>
      </div>
    </section>
  );
};

export default FeaturesSection;