// src/components/Header.jsx
import React from 'react';
import '../index.css';

const slugify = (str) => str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

const scrollToSection = (id) => {
  const element = document.getElementById(id);
  if (!element) return;

  // Вычисляем позицию с учётом фиксированной шапки (72px)
  const headerHeight = 72; // высота .header
  const elementTop = element.offsetTop;
  const offsetTop = elementTop - headerHeight;

  // Плавный скролл
  if ('scrollBehavior' in document.documentElement.style) {
    window.scrollTo({
      top: offsetTop,
      behavior: 'smooth'
    });
  } else {
    window.scrollTo(0, offsetTop);
  }
};

const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

const Header = () => {
  const navItems = ['Buy/Sell', 'Grow', 'Markets', 'Business', 'Support'];

  return (
    <header className="header">
      <a 
        href="/" 
        className="header__logo" 
        onClick={(e) => { e.preventDefault(); scrollToTop(); }}
      >
        <span className="logo__text">COINFLIP</span>
      </a>

      <nav className="header__nav">
        <ul className="nav__list">
          {navItems.map(item => {
            const id = slugify(item);
            return (
              <li key={id} className="nav__item">
                <a 
                  href={`#${id}`} 
                  className="nav__link"
                  onClick={(e) => { e.preventDefault(); scrollToSection(id); }}
                >
                  {item}
                </a>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="header__actions">
        <button className="btn btn--ghost">Sign In</button>
        <button className="btn btn--primary">Sign Up</button>
      </div>
    </header>
  );
};

export default Header;