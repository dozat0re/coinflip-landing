import React from 'react';
import './BuySellSection.css';

const BuySellSection = () => {
  const cryptoData = [
    { name: 'Bitcoin', symbol: 'BTC', price: '$56,290.30', change: '+1.68%', color: '#8B5CF6' },
    { name: 'Ethereum', symbol: 'ETH', price: '$4,284.81', change: '+4.36%', color: '#10B981' },
    { name: 'Cardano', symbol: 'ADA', price: '$1.88', change: '+3.43%', color: '#3B82F6' },
    { name: 'Wax', symbol: 'WAXP', price: '$0.97', change: '-2.62%', color: '#F59E0B' },
    { name: 'Polkadot', symbol: 'DOT', price: '$42.22', change: '+7.56%', color: '#EC4899' }
  ];

  return (
    <section id="buy-sell" className="buy-sell-section">
      <div className="buy-sell-header">
        <h2>Buy and sell with the lowest fees in the industry</h2>
        <p>Buy and sell 150+ cryptocurrencies with 20+ fiat currencies using bank transfers or your credit/debit card.</p>
        <a href="#learn-more" className="btn btn--ghost">Learn More →</a>
      </div>

      <div className="crypto-table">
        {cryptoData.map((item, index) => (
          <div key={index} className="crypto-row">
            <div className="crypto-info">
              <span className="crypto-name">{item.name}</span>
              <span className="crypto-symbol">{item.symbol}</span>
            </div>
            <div className="crypto-price">{item.price}</div>
            <div className={`crypto-change ${item.change.startsWith('+') ? 'positive' : 'negative'}`}>
              {item.change}
            </div>
            <div className="crypto-chart">
              {/* Простой SVG-график (упрощённая линия) */}
              <svg width="60" height="20" viewBox="0 0 60 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 18 L10 12 L20 15 L30 8 L40 14 L50 6 L58 10" 
                      stroke={item.color} 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="crypto-action">
              <button className="btn btn--ghost">Trade Now →</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default BuySellSection;