// src/App.jsx
import React from 'react';
import Header from './components/Header';
import FeaturesSection from './components/FeaturesSection'; 
import BuySellSection from './components/BuySellSection';
import GrowSection from './components/GrowSection';
import MarketsSection from './components/MarketsSection';
import BusinessSection from './components/BusinessSection';
import SupportSection from './components/SupportSection'; // 👈 импортируем
import './index.css';

const App = () => {
  return (
    <div className="app">
      <div className="glow-background">
        <div className="glow-circle glow-circle--1"></div>
        <div className="glow-circle glow-circle--2"></div>
        <div className="glow-circle glow-circle--3"></div>
        <div className="glow-circle glow-circle--4"></div>
        <div className="glow-circle glow-circle--5"></div>
      </div>
      
      <Header />
      <main>
        {/* Пока оставим просто placeholder */}
        <section id="top" className="hero">
          <h1>We make crypto clear and simple</h1>
          <p>Buy, sell, and grow your crypto with CoinFlip, the platform dedicated to every trader at every level.</p>
          <button className="btn btn--primary hero__cta">Start Now</button>
        </section>
        <FeaturesSection />
        <BuySellSection />
        <GrowSection />
        <MarketsSection />
        <BusinessSection />
        <SupportSection />
      </main>
    </div>
  );
};

export default App;